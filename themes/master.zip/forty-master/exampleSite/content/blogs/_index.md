---
title: "Lifestyle"
slug: "blogs"
image: pic02.jpg
date: 2017-10-31T22:27:21-05:00
draft: false
---

My blogs about technology and lifestyle.